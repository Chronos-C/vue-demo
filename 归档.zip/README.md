# Cleanup前端DEMO
## 安装依赖
```
npm i
```
## 启动项目
```
npm run serve
```
## 构建项目
```
npm run build
```